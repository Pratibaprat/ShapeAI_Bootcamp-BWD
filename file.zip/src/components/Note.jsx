import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        This was an Amazing bootcamp.I have learned a lot.thankyou so much for
        this wonderfull bootcamp.
      </p>
    </div>
  );
}

export default Note;
